typedef struct cylinder Cylinder;

Cylinder* create(float rad, float height);
void freeC(Cylinder* cylinder);
float radiusC(Cylinder* cylinder);
float heightC(Cylinder* cylinder);
float areaC(Cylinder* cylinder);
float volC(Cylinder* cylinder);