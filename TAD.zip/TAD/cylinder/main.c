#include <stdio.h>
#include <stdlib.h>
#include "cylinder.h"
#include <math.h>
#define PI 3.14

/*Caso não compile, cole aqui o código de cylinder.c*/

struct cylinder{
    float rad;
    float height;
};

Cylinder* create(float rad, float height){
    Cylinder *cylinder = malloc(sizeof(Cylinder));

    if(cylinder != NULL){
        cylinder->rad = rad;
        cylinder->height = height;
        return cylinder;
    }
}

void freeC(Cylinder* cylinder){
    free(cylinder);
}

float radiusC(Cylinder* cylinder){
    return cylinder->rad;
}

float heightC(Cylinder* cylinder){
    return cylinder->height;
}

float areaC(Cylinder* cylinder){
    return 2.0 * PI * cylinder->rad *(cylinder->rad + cylinder->height);
}

float volC(Cylinder* cylinder){
    return(PI * cylinder->rad * cylinder->rad * cylinder->height);
}

int main()
{
    float rad, height;
    Cylinder *cylinder;

    scanf("%f", &rad);
    scanf("%f", &height);
    cylinder = create(rad, height);

    printf("\nRaio: %.2f, Altura: %.2f\n", radiusC(cylinder), heightC(cylinder));
    printf("Area: %.2f\n", areaC(cylinder));
    printf("Volume: %.2f\n", volC(cylinder));

    freeC(cylinder);

    return 0;
}