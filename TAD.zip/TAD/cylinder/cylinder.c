#include <stdlib.h>
#include <math.h>
#include "cylinder.h"
#define PI 3.14

struct cylinder{
    float rad;
    float height;
};

Cylinder* create(float rad, float height){
    Cylinder *cylinder = malloc(sizeof(Cylinder));

    if(cylinder != NULL){
        cylinder->rad = rad;
        cylinder->height = height;
        return cylinder;
    }
}

void freeC(Cylinder* cylinder){
    free(cylinder);
}

float radiusC(Cylinder* cylinder){
    return cylinder->rad;
}

float heightC(Cylinder* cylinder){
    return cylinder->height;
}

float areaC(Cylinder* cylinder){
    return 2.0 * PI * cylinder->rad *(cylinder->rad + cylinder->height);
}

float volC(Cylinder* cylinder){
    return(PI * cylinder->rad * cylinder->rad * cylinder->height);
}