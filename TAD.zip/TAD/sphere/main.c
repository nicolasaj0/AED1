#include <stdlib.h>
#include <stdio.h>
#include "sphere.h"
#include <math.h>
#define Pi 3.14

/*Caso não compile, copie aqui o código de sphere.c*/

int main()
{
    float rad;
    Sphere *sphere;
    
    scanf("%f", &rad);
    sphere = createS(rad);

    printf("Raio: %.2f\n", radiusS(sphere));
    printf("Volume: %.2f\n", volS(sphere));
    printf("Area: %.2f\n", areaS(sphere));

    freeS(sphere);

    return 0;

}