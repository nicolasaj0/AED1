typedef struct sphere Sphere;

Sphere* createS(float rad);
void freeS(Sphere* sphere);
float radiusS(Sphere* sphere);
float volS(Sphere* sphere);
float areaS(Sphere* sphere);