#include <stdlib.h>
#include <math.h>
#include "sphere.h"
#define PI 3.14

struct sphere{
    float rad;
};

Sphere* createS(float rad){
    Sphere *sphere = malloc(sizeof(Sphere));

    if(sphere != NULL){
        sphere->rad = rad;
        return sphere;
    }
}

void freeS(Sphere* sphere){
    free(sphere);
}

float radiusS(Sphere* sphere){
    return sphere->rad;
}

float volS(Sphere* sphere){
    return (4.0 / 3.0) * PI * (sphere->rad * sphere->rad * sphere->rad);
}

float areaS(Sphere* sphere){
    return 4.0 * PI * (sphere->rad * sphere->rad);
}